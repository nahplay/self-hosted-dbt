import json
import requests
import os
from datetime import datetime


def lambda_handler(event, context):
    print(event)
    print(30 * ('-'))
    print(json.loads(event['Records'][0]['Sns']['Message'])['detail']['containers'])

    job_status = 'was successful! :white_check_mark:' if \
    json.loads(event['Records'][0]['Sns']['Message'])['detail']['containers'][0][
        'exitCode'] == 0 else 'has failed! Please take a :eyes: :red_circle: :x: <!channel>'

    image = json.loads(event['Records'][0]['Sns']['Message'])['detail']['containers'][0]['image']

    if 'amazonaws.com' in image:
        image_info = (
            f"*{image.split('.', 1)[0]}* account was used for a job \n"
            f"repository: *{image.split('.', 1)[1].split('/')[1].split(':')[0]}* \n"
            f"tag: *{image.split('.', 1)[1].split('/')[1].split(':')[1]}*"
        )
    else:
        image_info = '*No image info available for the image*'

    print(image)

    job_name = json.loads(event['Records'][0]['Sns']['Message'])['detail']['group'].split(':')[1]

    job_started_at = json.loads(event['Records'][0]['Sns']['Message'])['detail']['startedAt']

    job_finished_at = json.loads(event['Records'][0]['Sns']['Message'])['detail']['stoppedAt']

    datetime1 = datetime.strptime(job_started_at, "%Y-%m-%dT%H:%M:%S.%fZ")
    datetime2 = datetime.strptime(job_finished_at, "%Y-%m-%dT%H:%M:%S.%fZ")

    time_difference = datetime2 - datetime1

    seconds = time_difference.total_seconds() % 60
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)

    job_timing = f"{hours} hours, {minutes} minutes, {seconds:.1f} seconds"

    print('Check above...')
    # sns_message = json.loads(event)

    try:
        cloudwatch_link = f"https://{os.environ['AVAILABILITY_ZONE']}.console.aws.amazon.com/cloudwatch/home?region={os.environ['AVAILABILITY_ZONE']}#logsV2:log-groups/log-group/$252Fecs$252F{job_name}/log-events/ecs$252F{image.split('.', 1)[1].split('/')[1].split(':')[0]}$252F{json.loads(event['Records'][0]['Sns']['Message'])['detail']['containers'][0]['taskArn'].split('/')[-1]}"
    except IndexError:
        cloudwatch_link = '*Link is not available.*'

    print(cloudwatch_link)
    dataset = {
        'text': (
            f'The *{job_name} {job_status}* :robot_face: \n\n'
            f'Started at: *{job_started_at} UTC* \n'
            f'Finished at: *{job_finished_at} UTC* \n'
            f'Job took ~ *{job_timing}* :stopwatch:\n\n'
            'Image info: :rocket: \n'
            f'{image_info} \n'
            f'CloudWatch link :globe_with_meridians: : {cloudwatch_link}'
        )
    }

    headers = {
        'Content-type': 'application/json'
    }

    request = requests.post(os.environ['DBT_SLACK_WEBHOOK_URL'], data=json.dumps(dataset).encode("utf-8"),
                            headers=headers)
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
